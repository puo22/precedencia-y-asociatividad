from ExprLexer import ExprLexer
from ExprParser import ExprParser
from ExprVisitor import ExprVisitor
from antlr4 import *

class EvalVisitor(ExprVisitor):
    def visitProg(self, ctx):
        return self.visit(ctx.expr())

    def visitMulDiv(self, ctx):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        if ctx.op.text == '*':
            return left * right
        else:
            return left / right

    def visitAddSub(self, ctx):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        if ctx.op.text == '+':
            return left + right
        else:
            return left - right

    def visitId(self, ctx):
        return 1  # valor por defecto de variables

    def visitNum(self, ctx):
        return int(ctx.NUM().getText())

    def visitParens(self, ctx):
        return self.visit(ctx.expr())

def main():
    while True:
        try:
            text = input("Ingrese una expresión (o 'exit' para salir): ")
            if text.strip().lower() in ("exit", "salir"):
                print("Saliendo del programa...")
                break
            if text.strip() == "":
                continue
            input_stream = InputStream(text)
            lexer = ExprLexer(input_stream)
            stream = CommonTokenStream(lexer)
            parser = ExprParser(stream)
            tree = parser.prog()
            result = EvalVisitor().visit(tree)
            print("Resultado:", result)
        except Exception as e:
            print("Error:", e)


main()
